﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FutbolAdmin.Model
{
    public class TipoEventoModel
    {
        public int Id_TipoEvento { get; set; }
        public string descripcion { get; set; }
    }
}
